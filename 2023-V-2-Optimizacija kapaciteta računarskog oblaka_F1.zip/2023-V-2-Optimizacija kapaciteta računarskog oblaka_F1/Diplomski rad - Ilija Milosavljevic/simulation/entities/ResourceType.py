from aenum import Enum


class ResourceType(Enum):
    LICENCE = 1
    VIRTUAL_MACHINE = 2

