from aenum import Enum


class ResourceStatus(Enum):
    READY = 1
    IN_USE = 2